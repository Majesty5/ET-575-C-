// Rashida Thomas
// March 26, 2020
// ET 575
// Midterm #2


/*
Q1. Code the following prompt and value inputs and value editing in a Do While Loop
Enter a Valid Month and Year (Month Values 1-12 Year Values 2000-2020 inclusive) >


*/
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int month;
int year;
int main()
{


  cout << " Enter a value for month (1-12)" << endl;
  cin >> month;
  cout << " Enter a value for a year, ex: 1963" << endl;
  cin >> year;
{  do
  {
   (month>=1 && month<=12);
 } while (year>=2000 && year<=2020);
 if (true);
 cout << " Valid date";
 else
cout << " Invalid values";
}



    return 0;
}
