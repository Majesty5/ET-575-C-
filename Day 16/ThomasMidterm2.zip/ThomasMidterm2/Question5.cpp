// Rashida Thomas
// March 26, 2020
// ET 575
// Midterm #2


/*
Q5. Display the truth table for the following logical equation using a Excel or Google Sheets spreadsheet:

	If ((A > 5) AND ((!(B==2)) || (A==C)))

Determine whether it is TRUE or FALSE for the following values : A = 7, B = 2, C=7
*/


/*

7 > 5 (True)

2==2 (True) => !2==2 (False)



7==7 (True)

!2==2 (False) ||  7==7 (True) (TRUE)

True && True (TRUE)


*/
