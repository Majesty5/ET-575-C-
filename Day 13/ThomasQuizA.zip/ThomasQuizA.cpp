// Rashida Thomas
// ET 575
// QUIZ A Nested Loops
// DUE March 16, 2020
#include <iostream>
#include <iomanip>
#include <string>     // include the string library to use string variables
using namespace std;

int main()
{

//******************TASK******************************************************
// Implement a two-dimensional image using a nested loop.
// 1) Create an integer constant DIM and set it equal to 5.
// 2) Use a nested loop to print the output in terms of DIM.

int i;
int k;

for ( i=5; i<=5; i++ ) {

   for ( k=0; k=5; k++)
    if (i%2==0)
      {
     if (k%2 ==0)
    cout  <<" * " ;
    else
      cout << " - ";
   }
   else
    {
      if (k%2 ==0)
     cout << " - ";
     else
       cout<<" * ";
    }
   cout << endl;

 }
    return 0;
}
