#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

  int num = 16;
  int denom = 14;
  cout << "Let's divide 16 by 14 "<< endl << endl;
  cout << "**************************************************************"<< endl << endl;
  cout << "The quotient is " << num/denom << " Remainder " << num%denom << endl << endl;
    // cout << num%denom << endl << endl;


  return 0;
}
