#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

  // string no= " Introduction to c++ ";
  // string yes;
  cout << "**************************************************************"<< endl << endl;
  cout << left << setw(20) << " Name "  << setw(20)<< " Years of Presidency " << endl;
  cout << left << setw(20) << " Abraham Lincoln "  << setw(20)<< " 1860-1865 " << endl;
  cout << left << setw(20) << " Thomas Jefferson "  << setw(20)<< " 1801-1809 "<< endl << endl;
  cout << "**************************************************************"<< endl;


  return 0;
}
