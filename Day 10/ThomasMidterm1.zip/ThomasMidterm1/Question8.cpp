#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

//Given the following, what is the final value of W?

  int W= 0, x=1, y=2, z=3;

  cout << "W=x+y*z+14/y" << endl << endl;
  cout << "0 = 1 + 2* 3 + 14/2" << endl << endl;
  cout << "0 = 1 + 6 + 14/2" << endl << endl;
  cout << "0 = 1 + 6 + 7" << endl << endl;
  cout << "0 = 7 + 7" << endl << endl;
  cout << "0 = 14 " << endl << endl;
   cout << "FALSE"<< endl << endl;



  return 0;
}
