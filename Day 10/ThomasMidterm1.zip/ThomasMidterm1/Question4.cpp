#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

  // int surpriseNum = rand() % <9> + 100;
  int surpriseNum = rand(9) 110-100 +1;
  cout << surpriseNum << endl << endl;
  // cout << no.replace(17,1, "C") << endl << endl;


  return 0;
}
