// Rashida Thomas
// ET 575
// Practice Test
// Problem # 2
// Due March 23, 2020

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
  /* Task:
  Coding Question (you must code this problem and submit via Blackboard):

  Using Nested Loops display  the following exactly as it is shown below:

                                                             Columns

  Rows
     1        2       3       4       5       6        7       8        9

      1          11      12      13     14    15      16     17     18      19

       2         21       22      23     24    25      26     27     28      29

       3         31       32      33     34    35      36      37    38      39

       4         41       42       43     44    45     46      47    48      49

 */




for (int row = 1; row <4; row++)   //Outer loop
  {

    for (int col = 1; col <9; col++)  // Inner loop
      {
        if (col==4 && row==4)

          // cout << "O";

        if (col==row-1 || col==col-row-1 || row==row-1 || col==7 || col+row==7)

            cout << row;
           else
            cout << col;

    }
            cout <<endl;
    }


    return 0;
}
