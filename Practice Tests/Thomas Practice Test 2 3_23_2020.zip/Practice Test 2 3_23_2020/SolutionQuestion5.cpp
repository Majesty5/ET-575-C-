// Rashida Thomas
// ET 575
// Practice Test
// Question # 5
// Due March 23, 2020

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
  /* Task:
  Display the truth table for the following logical equation:

  	If ((( A > 5) || (B<0)) && (!((C%2) == 1))))

  Determine whether it is TRUE or FALSE for the following values : A = 7, B = 2, C=7
 */
bool z;
bool z=false;
int A=7;
int B=2;
int C=7;

	if ((( A> 5) || (B<0)) && (!((C%2) == 1))))

  cout << z << endl;
  else

  cout << y<< endl;

  //
  // T F F =F





    return 0;
}
