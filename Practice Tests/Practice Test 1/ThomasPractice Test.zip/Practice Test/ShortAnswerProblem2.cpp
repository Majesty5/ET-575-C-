// Rashida Thomas
// Practice Test 575
// Problem 1
// Due: February 24, 2020
#include <iostream>

using namespace std;

int main()
{

//*******************************TASK*************************************
              // 1. Write a single C++ statement that will:
              // Print the letter "W" given the code and using the string:
              // string greting ="Hello World"
//  ******************************************************

  string greeting = "Hello World";

  cout << greeting[6] << endl;

     return 0;
}
