// Rashida Thomas
// Practice Test 575
// Problem 1
// Due: February 24, 2020
#include <iostream>

using namespace std;

int main()
{

//*******************************TASK*************************************
              // 1. Write a single C++ statement that will:
              // Print the string "World" uring the variable:
              // string s ="Hello World"
//  ******************************************************

  string s = "Hello World";

  cout << s.substr(6,10) << endl;

     return 0;
}
